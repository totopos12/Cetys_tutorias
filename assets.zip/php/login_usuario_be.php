<?php
session_start();
include 'conexion_be.php';

$correo = $_POST['correo'];
$contrasena = $_POST['contrasena'];
$contrasena = hash('sha512', $contrasena);

$validar_login = mysqli_query($conexion, "SELECT * FROM usuarios WHERE 
correo='$correo' AND contrasena='$contrasena'");

if (mysqli_num_rows($validar_login) > 0) {
    $row = mysqli_fetch_assoc($validar_login); // Obtener los datos del usuario
    $_SESSION['usuario'] = $correo; // Guardar el correo en la sesión
    $_SESSION['nombre_completo'] = $row['nombre_completo']; // Guardar el nombre completo en la sesión
    $_SESSION['id'] = $row['id']; // Guardar el ID del usuario en la sesión
    header("location: ../bienvenida.php");
    exit;
} else {
    echo '
        <script>
            alert("El usuario o la contraseña son incorrectos");
            window.location = "../index.php";
        </script>
    ';
    exit;
}
