<?php

include 'conexion_be.php';

$nombre_completo = $_POST['nombre_completo'];
$correo = $_POST['correo'];
$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];

// Encriptar contraseña
$contrasena = hash('sha512', $contrasena);

// Validar formato de correo electrónico
if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    echo '
        <script>
            alert("Correo electrónico no válido");
            window.location = "../index.php";
        </script>
    ';
    exit();
}

// Verificar dominio del correo electrónico
$allowed_domains = ['cetys.edu.mx', 'cetys.edu'];
$domain = substr(strrchr($correo, "@"), 1);

if (!in_array($domain, $allowed_domains)) {
    echo '
        <script>
            alert("El correo electrónico debe terminar con @cetys.edu.mx o @cetys.edu");
            window.location = "../index.php";
        </script>
    ';
    exit();
}

// Verificar existencia del correo electrónico
if (!checkEmailExists($correo)) {
    echo '
        <script>
            alert("Correo electrónico no existe");
            window.location = "../index.php";
        </script>
    ';
    exit();
}

// Verificar que no se repita el correo
$stmt = $conexion->prepare("SELECT * FROM usuarios WHERE correo = ?");
$stmt->bind_param("s", $correo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo '
        <script>
            alert("Ya existe una cuenta con este correo");
            window.location = "../index.php";
        </script>
    ';
    exit();
}

// Verificar que no se repita el usuario
$stmt = $conexion->prepare("SELECT * FROM usuarios WHERE usuario = ?");
$stmt->bind_param("s", $usuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo '
        <script>
            alert("Ya existe una cuenta con este nombre de usuario");
            window.location = "../index.php";
        </script>
    ';
    exit();
}

// Insertar nuevo usuario
$stmt = $conexion->prepare("INSERT INTO usuarios (nombre_completo, correo, usuario, contrasena) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $nombre_completo, $correo, $usuario, $contrasena);

if ($stmt->execute()) {
    echo '
        <script>
            alert("Usuario almacenado exitosamente");
            window.location = "../index.php";
        </script>
    ';
} else {
    echo '
        <script>
            alert("Inténtalo de nuevo, usuario no almacenado");
            window.location = "../index.php";
        </script>
    ';
}

$stmt->close();
$conexion->close();

// Función para verificar la existencia del correo electrónico
function checkEmailExists($email) {
    $domain = substr(strrchr($email, "@"), 1);
    return checkdnsrr($domain, "MX");
}

