<?php
session_start();
include 'conexion_be.php'; // Conexión a la base de datos

if (!isset($_SESSION['usuario']) || !isset($_SESSION['nombre_completo'])) {
    exit("Usuario no autenticado.");
}

$nombre_destino = $_POST['nombre_destino'] ?? '';
if (empty($nombre_destino)) {
    exit("Error al obtener el nombre del destinatario.");
}

$nombre_destino = mysqli_real_escape_string($conexion, $nombre_destino);
$nombre_origen = mysqli_real_escape_string($conexion, $_SESSION['nombre_completo']);

// Obtener el ID del destinatario
$result = mysqli_query($conexion, "SELECT id FROM usuarios WHERE nombre_completo='$nombre_destino'");
if ($result && mysqli_num_rows($result) > 0) {
    $user_data = mysqli_fetch_assoc($result);
    $incoming_msg_id = $user_data['id'];

    // Obtener el ID del usuario actual
    $result_origen = mysqli_query($conexion, "SELECT id FROM usuarios WHERE nombre_completo='$nombre_origen'");
    if ($result_origen && mysqli_num_rows($result_origen) > 0) {
        $origen_data = mysqli_fetch_assoc($result_origen);
        $outgoing_msg_id = $origen_data['id'];

        // Consulta para obtener los mensajes
        $sql_messages = mysqli_query($conexion, "SELECT * FROM messages WHERE 
            (incoming_msg_id = $incoming_msg_id AND outgoing_msg_id = $outgoing_msg_id) 
            OR (incoming_msg_id = $outgoing_msg_id AND outgoing_msg_id = $incoming_msg_id) 
            ORDER BY msg_id ASC");

        // Mostrar los mensajes
        $messages = '';
        if ($sql_messages && mysqli_num_rows($sql_messages) > 0) {
            while ($row = mysqli_fetch_assoc($sql_messages)) {
                if ($row['outgoing_msg_id'] == $outgoing_msg_id) {
                    $messages .= '<div class="message sent">' . htmlspecialchars($row['msg']) . '</div>';
                } else {
                    $messages .= '<div class="message received">' . htmlspecialchars($row['msg']) . '</div>';
                }
            }
            echo $messages;
        } else {
            echo "No hay mensajes para mostrar.";
        }
    } else {
        exit("Error al obtener el ID del usuario actual.");
    }
} else {
    exit("No se encontró el usuario.");
}
