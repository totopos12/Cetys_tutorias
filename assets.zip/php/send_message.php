<?php
session_start();
include 'conexion_be.php'; // Conexión a la base de datos

if (!isset($_SESSION['usuario']) || !isset($_SESSION['nombre_completo'])) {
    exit("Usuario no autenticado.");
}

$mensaje = $_POST['mensaje'] ?? '';
$nombre_destino = $_POST['nombre_destino'] ?? '';

if (empty($mensaje) || empty($nombre_destino)) {
    exit("El mensaje o destinatario no pueden estar vacíos.");
}

$mensaje = mysqli_real_escape_string($conexion, $mensaje);
$nombre_destino = mysqli_real_escape_string($conexion, $nombre_destino);

// Obtener el ID del destinatario
$result = mysqli_query($conexion, "SELECT id FROM usuarios WHERE nombre_completo='$nombre_destino'");
if ($result && mysqli_num_rows($result) > 0) {
    $user_data = mysqli_fetch_assoc($result);
    $incoming_msg_id = $user_data['id'];
    
    // Obtener el ID del usuario actual
    $outgoing_msg_id = $_SESSION['id'];

    // Guardar el mensaje en la base de datos
    $sql_insert = "INSERT INTO messages (incoming_msg_id, outgoing_msg_id, msg) VALUES ('$incoming_msg_id', '$outgoing_msg_id', '$mensaje')";
    if (mysqli_query($conexion, $sql_insert)) {
        echo "Mensaje enviado.";
    } else {
        exit("Error al enviar el mensaje.");
    }
} else {
    exit("No se encontró el usuario.");
}
