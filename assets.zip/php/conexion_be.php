<?php
$conexion = mysqli_connect("localhost", "root", "", "login_register_db");

// Verificar si hay un error de conexión
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

