$(document).ready(function() {
    $('#send-message-form').submit(function(event) {
        event.preventDefault(); // Prevenir el envío del formulario

        $.ajax({
            type: 'POST',
            url: 'send_message.php',
            data: $(this).serialize(), // Serializa los datos del formulario
            success: function(response) {
                // Agregar el mensaje enviado al chat
                $('#chat-content').append('<div class="message sent">' + $('#message').val() + '</div>');
                $('#message').val(''); // Limpiar el campo de texto
            },
            error: function() {
                alert('Error al enviar el mensaje.');
            }
        });
    });
});


